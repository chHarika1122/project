package com.capgemini.WalletAccount.dao;

import java.sql.ResultSet;
import java.sql.SQLException;


import com.capgemini.WalletAccount.bean.BankBean;
import com.capgemini.WalletAccount.exceptions.BankAccountException;
import com.capgemini.WalletAccount.exceptions.BankAccountNotFoundException;
import com.capgemini.WalletAccount.exceptions.InsuffecientBankBalanceException;


public interface BankDao {
	public void createBankAccount(String accountNumber, BankBean user) throws SQLException, Exception;
	public BankBean viewBankAccount(String accountNumber) throws BankAccountNotFoundException, Exception;
	public boolean creditMoney(String accountNumber, int amount) throws BankAccountNotFoundException, SQLException, Exception;
	public boolean debitMoney(String accountNumber1,String accountNumber2, int amount) throws InsuffecientBankBalanceException, BankAccountNotFoundException, BankAccountException, SQLException, Exception;
	public void validateBankAccount(String accountNumber) throws BankAccountNotFoundException, Exception;
	public void checkSameBankAccount(String accountNumber1,String accountNumber2)throws BankAccountException, Exception ;
	public void checkSuffecientBankBalance(String accountNumber1, int amount) throws InsuffecientBankBalanceException, Exception;
	public ResultSet getAllWalletAccounts() throws Exception;
	

}
