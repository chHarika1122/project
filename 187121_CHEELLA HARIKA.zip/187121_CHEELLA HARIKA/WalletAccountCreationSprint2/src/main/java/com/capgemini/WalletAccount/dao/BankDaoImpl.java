package com.capgemini.WalletAccount.dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import com.capgemini.WalletAccount.bean.BankBean;
import com.capgemini.WalletAccount.databaseutil.DataBaseUtil;
import com.capgemini.WalletAccount.exceptions.BankAccountException;
import com.capgemini.WalletAccount.exceptions.BankAccountNotFoundException;
import com.capgemini.WalletAccount.exceptions.InsuffecientBankBalanceException;

public class BankDaoImpl implements BankDao{
	Map<String, BankBean> userList=new HashMap<String, BankBean>();
	String string=null;
	Connection connect=null;
	PreparedStatement ps=null;
	int row;
	public void createBankAccount(String accountNumber, BankBean user) throws Exception {
		// TODO Auto-generated method stub
		try {
			connect=DataBaseUtil.getConnection();
			string="insert into account1 values(?,?,?,?,?)";
			ps=connect.prepareStatement(string);
			ps.setString(1,accountNumber);
			ps.setString(2,user.getaccName());
			ps.setLong(3,user.getMobileNumber());
			ps.setString(4,user.getEm_id());
			ps.setInt(5,user.getaccBalance());
			ps.executeUpdate();
			connect.close();
		}
		catch(Exception e)
		{
			throw e;
		}
		
	}

	public BankBean viewBankAccount(String accountNumber) throws Exception {
		// TODO Auto-generated method stub
		ResultSet rs=null;
		BankBean user=new BankBean();
		try {
			validateBankAccount(accountNumber);
			connect=DataBaseUtil.getConnection();
			Statement s=connect.createStatement();
			rs=s.executeQuery("select * from account1 where accountnumber="+accountNumber);
			while(rs.next())
			{
				user.setaccName(rs.getString(2));
				user.setMobileNumber(rs.getLong(3));
				user.setEm_id(rs.getString(4));
				user.setaccBalance(rs.getInt(5));
			}
			connect.close();
			return user;
		}
		catch(Exception e) {
			throw e;
		}
		
	}

	public boolean creditMoney(String accountNumber, int amount) throws Exception{
		// TODO Auto-generated method stub
		int temp=0;
		try {
			validateBankAccount(accountNumber);
			temp=getBalance(accountNumber);
			temp=temp+amount;
			connect=DataBaseUtil.getConnection();
			Statement s=connect.createStatement();
			s.executeUpdate("update account1 set accbalance="+temp+" where accountnumber="+accountNumber);
			connect.close();
			return true;
			
		}
		catch(Exception e)
		{
			throw e;
		}
		
	}

	public boolean debitMoney(String accountNumber1, String accountNumber2, int amount) throws Exception {
		// TODO Auto-generated method stub
		int temp1=0,temp2=0;
			try {
				checkSameBankAccount(accountNumber1, accountNumber2);
				temp1=getBalance(accountNumber1);
				temp2=getBalance(accountNumber2);
				checkSuffecientBankBalance(accountNumber1, amount);
				temp1=temp1-amount;
				temp2=temp2+amount;
				connect=DataBaseUtil.getConnection();
				Statement s=connect.createStatement();
				s.executeUpdate("update account1 set accbalance="+temp1+" where accountnumber="+accountNumber1);
				s.executeUpdate("update account1 set accbalance="+temp2+" where accountnumber="+accountNumber2);
				connect.close();
				return true;
			}
			catch(Exception e)
			{
				throw e;
			}
		
	}
	public int getBalance(String accountNumber) throws SQLException {
		ResultSet rs=null;
		int balance = 0;
		try {
			connect=DataBaseUtil.getConnection();
			Statement s=connect.createStatement();
			rs=s.executeQuery("select * from account1 where accountnumber="+accountNumber);
			while(rs.next())
			{
				balance=rs.getInt(5);
			}
			connect.close();
		}
		catch(SQLException e)
		{
			throw e;
		}
		return balance;
		
	}
	public void checkSameBankAccount(String accountNumber1, String accountNumber2) throws Exception{
		// TODO Auto-generated method stub
		try {
			if(accountNumber1.equals(accountNumber2))
			{
				throw new BankAccountException();
			}
		}
		catch(Exception e)
		{
			throw e;
		}
		
	}

	public void checkSuffecientBankBalance(String accountNumber1, int amount) throws Exception {
		// TODO Auto-generated method stub
		try {
			int temp=getBalance(accountNumber1);
			if(temp<amount)
			{
				throw new InsuffecientBankBalanceException();
			}
		}
		catch(Exception e)
		{
			throw e;
		}
	}

	public void validateBankAccount(String accountNumber) throws Exception {
		// TODO Auto-generated method stub
		ResultSet rs=null;
		try
		{
			connect=DataBaseUtil.getConnection();
			Statement s=connect.createStatement();
			rs=s.executeQuery("select * from account1 where accountnumber="+accountNumber);
			if(!rs.next())
			{
				throw new BankAccountNotFoundException();
			}
			connect.close();
		}
		catch(Exception e)
		{
			throw e;
		}
	}

	public ResultSet getAllWalletAccounts() throws Exception {
		// TODO Auto-generated method stub
		ResultSet rs=null;
		try
		{
			connect=DataBaseUtil.getConnection();
			Statement s=connect.createStatement();
			rs=s.executeQuery("select * from account1");
		}
		catch(Exception e)
		{
			throw e;
		}
		return rs;
	}

}
