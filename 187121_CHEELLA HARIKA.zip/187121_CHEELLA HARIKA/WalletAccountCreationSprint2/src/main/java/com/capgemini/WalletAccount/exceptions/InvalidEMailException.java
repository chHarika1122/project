package com.capgemini.WalletAccount.exceptions;
@SuppressWarnings("serial")
public class InvalidEMailException extends Exception {
	public InvalidEMailException()
	{
		super("The Email Format submitted is Invalid");
	}

}
