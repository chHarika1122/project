package com.capgemini.collection.exception;

@SuppressWarnings("serial")
public class InsuffecientBankBalanceException extends Exception
{
	public InsuffecientBankBalanceException() 
	{
		super("The Sender's Wallet Balance is insuffecient");
	}

}
