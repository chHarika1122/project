package com.capgemini.collection.dao;

import java.util.HashMap;


import com.capgemini.collection.bean.BankBean;
import com.capgemini.collection.exception.BankAccountException;
import com.capgemini.collection.exception.BankAccountNotFoundException;
import com.capgemini.collection.exception.InsuffecientBankBalanceException;


public interface BankDao {
	public void createBankAccount(String AccountNumber, BankBean user);
	public BankBean viewBankAccount(String AccountNumber) throws BankAccountNotFoundException;
	public boolean creditMoney(String AccountNumber, int Amount) throws BankAccountNotFoundException;
	public boolean debitMoney(String AccNumber1,String AccNumber2, int Amount) throws InsuffecientBankBalanceException,BankAccountNotFoundException, BankAccountException;
	public void validateBankAccount(String accountNumber) throws BankAccountNotFoundException;
	public void checkSuffecientBankBalance(String accNumber1, int amount) throws InsuffecientBankBalanceException;
	public HashMap<String, BankBean> getAllWalletAccounts();
	

}
