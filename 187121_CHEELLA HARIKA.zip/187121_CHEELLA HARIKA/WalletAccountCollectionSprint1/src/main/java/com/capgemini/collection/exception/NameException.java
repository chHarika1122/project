package com.capgemini.collection.exception;

@SuppressWarnings("serial")
public class NameException extends Exception{
	public NameException()
	{
		super("Name Format is incorrect. Check if the First Letter is in uppercase");
	}

}
