package com.capgemini.test;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

import com.capgemini.WalletAccount.bean.BankBean;
import com.capgemini.WalletAccount.service.BankService;
import com.capgemini.WalletAccount.service.BankServiceImpl;
@TestInstance(Lifecycle.PER_CLASS)
class WalletAccountTest {

		BankService service;
		String string=null;
		@BeforeAll
		void intialize(){
			service=new BankServiceImpl();
		}
		
		@Test
		void testCreateAccount() throws SQLException, Exception
		{
			BankBean bb=new BankBean();
			bb.setaccName("Saisree");
			bb.setMobileNumber(4573547564L);
			bb.setaccBalance(1000);
			bb.setEm_id("Saisree@gmail.com");
			string=service.createBankAccount(bb);
			assertNotEquals(null, string);
		}
		
		@Test
		void testaddMoney() throws SQLException, Exception{
			if(service.creditMoney(string, 1000))
			{
				assertTrue(true);
			}
			else
			{
				assertFalse(false);
			}
		}
		
		@Test
		void testTransfer() throws Exception
		{
			BankBean bb=new BankBean();
			bb.setaccName("Saisree");
			bb.setMobileNumber(5643643452L);
			bb.setaccBalance(2000);
			bb.setEm_id("Saisree@gmail.com");
			String newstring=service.createBankAccount(bb);
			if(service.debitMoney(string, newstring, 2000))
			{
				assertTrue(true);
			}
			else
			{
				assertFalse(false);
			}
		}
	}

