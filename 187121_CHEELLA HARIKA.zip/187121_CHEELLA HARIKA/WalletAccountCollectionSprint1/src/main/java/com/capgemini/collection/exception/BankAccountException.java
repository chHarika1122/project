package com.capgemini.collection.exception;

@SuppressWarnings("serial")
public class BankAccountException extends Exception 
{
  public BankAccountException()
	{
		super("The Wallet Number's cannot be same For Transfer");
	}

}
