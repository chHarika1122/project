package com.capgemini.collection.userinterface;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;


import java.util.Scanner;
import java.util.Set;

import com.capgemini.collection.bean.BankBean;
import com.capgemini.collection.service.BankServiceImpl;

public class Starter {
	
	static BankServiceImpl service=new BankServiceImpl();
	public static void showMenu() 
	{
		System.out.println("Menu");
		System.out.println("01. Create an Account");
		System.out.println("02. Add Money to Account");
		System.out.println("03. Show Details");
		System.out.println("04. Transfer Money");
		System.out.println("05. Show All Accounts");
		System.out.println("06. Exit");
		System.out.print("Enter Your Choice : ");
	}
	public static void main(String[] args)
	{
		 
		Scanner scanner = new Scanner(System.in);
		int choice;
		while(true)
		{
			showMenu();
			choice = scanner.nextInt();
			switch(choice)
			{
			case 1:
				System.out.println(" Wallet Account Creation");
				try
				{
					BankBean user=new BankBean();
					System.out.println("Enter your Name:");
					user.setaccName(scanner.next());
					System.out.println("Enter your Mobile Number:");
					user.setMobileNumber(scanner.nextLong());
					System.out.println("Enter your E-mail:");
					user.setEm_id(scanner.next());
					user.setaccBalance(0);
					String AccountNumber=service.newBankAccount(user);
					System.out.println("Your Wallet Number is : "+AccountNumber);
					
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 2:
				
				try {
					System.out.println("Enter the Wallet Account Number to be credited:");
					String AccountNumber=scanner.next();
					System.out.println("Enter the Amount to add into the WalletAccount "+AccountNumber);
					int Amount=scanner.nextInt();
					service.creditMoney(AccountNumber, Amount);
					System.out.println("The Wallet is Successfully credited");
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 3:
				
				try
				{
					System.out.println("Enter the Wallet Account Number:");
					String AccountNumber=scanner.next();
					BankBean user=service.showBankAccount(AccountNumber);
					System.out.println("Name:"+user.getaccName()+"\nMobile No:"+user.getMobileNumber()+"\nEmail:"+user.getEm_id()+"\nBalance:"+user.getaccBalance());
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 4:
				
				try
				{
					System.out.println("Enter the Sender's Wallet Account Number:");
					String SenderAccountNumber=scanner.next();
					System.out.println("Enter the Reciever's Wallet Account Number:");
					String RecieverAccountNumber=scanner.next();
					System.out.println("Enter the Amount to be Transferred:");
					int TransferAmount=scanner.nextInt();
					service.debitAmount(SenderAccountNumber, RecieverAccountNumber, TransferAmount);
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 5:
				try
				{
					Map<String, BankBean> userlist=new HashMap<String, BankBean>();
					userlist=service.getAllWalletAccounts();
					if(!userlist.isEmpty())
					{

						Set<Entry<String, BankBean>> set=userlist.entrySet();
						Iterator<Entry<String, BankBean>> i=set.iterator();
						while(i.hasNext())
						{
							Map.Entry<String, BankBean> me=(Map.Entry<String, BankBean>)i.next();
							BankBean result=me.getValue();
							System.out.println("\nThe Available Wallet Accounts are...");
						
							System.out.println("Wallet Account Number: "+me.getKey()+"\nUser Name: "+result.getaccName());
						}
					}
					else
					{
						System.out.println("No Wallet Accounts Found");
					}
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 6:
				System.out.println("End of Service");
				System.exit(0);
			default:
				System.out.println("No Such Services Found");
				break;
			}
		}
	}

}
