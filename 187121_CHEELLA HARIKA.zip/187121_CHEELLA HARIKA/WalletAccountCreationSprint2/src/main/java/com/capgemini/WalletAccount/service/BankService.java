package com.capgemini.WalletAccount.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

import com.capgemini.WalletAccount.bean.BankBean;
import com.capgemini.WalletAccount.exceptions.BankAccountException;
import com.capgemini.WalletAccount.exceptions.BankAccountNotFoundException;
import com.capgemini.WalletAccount.exceptions.InsuffecientBankBalanceException;
import com.capgemini.WalletAccount.exceptions.InvalidEMailException;
import com.capgemini.WalletAccount.exceptions.InvalidMobileNumberException;



public interface BankService {
	public String createBankAccount(BankBean user) throws InvalidEMailException, InvalidMobileNumberException, SQLException, Exception;
	public BankBean viewBankAccount(String accountNumber) throws BankAccountNotFoundException, Exception;
	public boolean creditMoney(String accountNumber, int amount) throws BankAccountNotFoundException, SQLException, Exception;
	public boolean debitMoney(String accountNumber1,String accountNumber2, int amount) throws InsuffecientBankBalanceException, BankAccountNotFoundException, BankAccountException, Exception;
	public ResultSet getAllWalletAccounts() throws Exception;
}
