package com.capgemini.collection.exception;

@SuppressWarnings("serial")
public class BankAccountNotFoundException extends Exception{
	public BankAccountNotFoundException()
	{
		super("Check the Wallet Number you have Entered");
	}

}
