package com.capgemini.collection.service;

import java.util.HashMap;
import java.util.Random;

import com.capgemini.collection.bean.BankBean;
import com.capgemini.collection.dao.BankDao;
import com.capgemini.collection.dao.BankDaoImpl;
import com.capgemini.collection.exception.BankAccountException;
import com.capgemini.collection.exception.BankAccountNotFoundException;
import com.capgemini.collection.exception.InsuffecientBankBalanceException;
import com.capgemini.collection.exception.InvalidEMailException;
import com.capgemini.collection.exception.InvalidMobileNumberException;


public class BankServiceImpl extends Validator implements BankService{
	BankDao dao=new BankDaoImpl();
	Validator v=new Validator();
	@Override
	public String newBankAccount(BankBean user) throws  InvalidEMailException, InvalidMobileNumberException{
		// TODO Auto-generated method stub
		String AccountNumber=null;
		try 
		{
			v.validator(user);
			Random rand=new Random();
			int num=rand.nextInt(9000)+1000;
			 AccountNumber=String.valueOf(num);
			dao.createBankAccount(AccountNumber, user);
		}
		catch(Exception e)
		{
			throw e;
		}
		return AccountNumber;
		
	}


	@Override
	public BankBean showBankAccount(String AccountNumber) throws BankAccountNotFoundException{

		try
		{
			return dao.viewBankAccount(AccountNumber);
		}
		catch(Exception e)
		{
			throw e;
		}
	}

	@Override
	public boolean creditMoney(String AccountNumber, int Amount) throws BankAccountNotFoundException {
		// TODO Auto-generated method stub
		try
		{
		
			return dao.creditMoney(AccountNumber, Amount);
		}
		catch(Exception e)
		{
			throw e;
		}
		
	}

	@Override
	public boolean debitAmount(String AccountNumber1, String AccountNumber2, int Amount) throws InsuffecientBankBalanceException,BankAccountNotFoundException,BankAccountException {
		// TODO Auto-generated method stub
		try {
			return dao.debitMoney(AccountNumber1, AccountNumber2, Amount);
			}
		catch(Exception e)
		{
			throw e;
		}
		
	}


	@Override
	public HashMap<String, BankBean> getAllWalletAccounts() {
		// TODO Auto-generated method stub
		try {
			return dao.getAllWalletAccounts();
		}
		catch(Exception e)
		{
			throw e;
		}
	}

}
