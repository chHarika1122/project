package com.capgemini.collection.service;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.collection.bean.BankBean;
import com.capgemini.collection.exception.InvalidEMailException;
import com.capgemini.collection.exception.InvalidMobileNumberException;


public class Validator {

	public void validator(BankBean user) throws InvalidEMailException,InvalidMobileNumberException
	{
		try {
			validatePhoneNumber(user.getMobileNumber());
			validateEmail(user.getEm_id());
			
		} catch (InvalidMobileNumberException | InvalidEMailException e) {
			// TODO Auto-generated catch block
			throw e;
		}
	}
	public void validateEmail(String string) throws InvalidEMailException
	{
		try
		{
			Pattern p = Pattern.compile("\\b[a-zA-Z0-9._%-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}\\b");
			Matcher m = p.matcher(string);
			if(!m.matches())
			{
				throw new InvalidEMailException();
			}
		}
		catch(Exception e)
		{
			throw e;
		}
	}
	public void validatePhoneNumber(long phone) throws InvalidMobileNumberException
	{
		try
		{
			String temp=String.valueOf(phone);
			Pattern p = Pattern.compile("\\d{10}");
			Matcher m = p.matcher(temp);
			if(!m.matches() || (!(temp.length()==10)))
			{
				throw new InvalidMobileNumberException();
			}
		}
		catch(Exception e)
		{
			throw e;
		}
	}
	
}
