package com.capgemini.WalletAccount.exceptions;

@SuppressWarnings("serial")
public class InsuffecientBankBalanceException extends Exception{
	public InsuffecientBankBalanceException() {
		super("The Sender Acoount Balance is not suffecient");
	}

}
