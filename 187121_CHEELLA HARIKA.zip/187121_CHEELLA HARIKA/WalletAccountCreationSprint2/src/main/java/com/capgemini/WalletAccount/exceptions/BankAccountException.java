package com.capgemini.WalletAccount.exceptions;
@SuppressWarnings("serial")
public class BankAccountException extends Exception {
	public BankAccountException()
	{
		super("the account numbers entered are same.");
	}

}
