package com.capgemini.collection.exception;

@SuppressWarnings("serial")
public class InvalidMobileNumberException extends Exception{
	public InvalidMobileNumberException()
	{
		super("Check the Phone Number you have Entered");
	}

}
